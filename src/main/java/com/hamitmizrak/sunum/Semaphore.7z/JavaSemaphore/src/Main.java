import java.util.concurrent.Semaphore;

public class Main {
    static class MyThread extends Thread {
        Semaphore sem;
        String threadName;

        public MyThread(Semaphore sem, String threadName) {
            super(threadName);
            this.sem = sem;
            this.threadName = threadName;
        }

        @Override
        public void run() {
            System.out.println("Başlatılıyor " + threadName);
            try {
                int count = 1;
                System.out.println(threadName + " is waiting for a permit.");
                sem.acquire(); // izin istemek 1 0
                for (int i = 0; i < 5; i++) {
                    System.out.println(threadName + " çalışıyor : " + count);
                    Thread.sleep(1000);
                    count++;
                }

            } catch (InterruptedException exc) {
                System.out.println(exc);
            }
            System.out.println(threadName + " releases the permit.");
            sem.release(); // serbest bırakmak

        }

    }

    // Driver class
    public static class SemaphoreDemo {
        public static void main(String args[]) throws InterruptedException {
            Semaphore sem = new Semaphore(2);
            MyThread thread1 = new MyThread(sem, "Thread1");
            MyThread thread2 = new MyThread(sem, "Thread2");
            MyThread thread3 = new MyThread(sem, "Thread3");
            thread1.start();
            thread2.start();
            thread3.start();
        }
    }
}
