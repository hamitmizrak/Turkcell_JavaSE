/**
 * @author Emre YILDIZ
 */
public class Worker
{
    public  String isim;
    public  String soyisim;
    public int maas;
    private int calisanNo;
    private float calisanSeviye;

    public Worker()
    {
        System.out.println("default constructor");
    }

    public Worker(String...strings)
    {
        System.out.println("default constructor");
    }


    private Worker(String isim, String soyisim) {
        this.isim = isim;
        this.soyisim = soyisim;
    }

    public Worker(String isim, String soyisim, int maas) {
        this.isim = isim;
        this.soyisim = soyisim;
        this.maas = maas;
        this.calisanNo = 5;
        this.calisanSeviye = 5.0f;
    }

    public String isimSoyisimGetir()
    {
        return this.isim + " " + this.soyisim;
    }
    private void deneme()
    {
        System.out.println("private function call");
    }
    protected void deneme2()
    {
        System.out.println("deneme protected");
    }

    @Override
    public String toString() {
        return "super.toString()";
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getSoyisim() {
        return soyisim;
    }

    public void setSoyisim(String soyisim) {
        this.soyisim = soyisim;
    }

    public int getMaas() {
        return maas;
    }

    public void setMaas(int maas) {
        this.maas = maas;
    }

    public int getCalisanNo() {
        return calisanNo;
    }

    public void setCalisanNo(int calisanNo) {
        this.calisanNo = calisanNo;
    }

    public float getCalisanSeviye() {
        return calisanSeviye;
    }

    public void setCalisanSeviye(float calisanSeviye) {
        this.calisanSeviye = calisanSeviye;
    }
}
