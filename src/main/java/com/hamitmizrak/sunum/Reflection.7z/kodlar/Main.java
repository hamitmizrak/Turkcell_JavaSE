import java.lang.reflect.*;

/**
 * @author Emre YILDIZ
 */
public class Main extends Object {
    public static final void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException, InstantiationException {
        Class<?> worker = Class.forName("Worker");
        Class<?> engineer = Class.forName("Engineer");
        //public constructorları bu array e atar
        Constructor[] constructors = worker.getConstructors();
        // tanıtılmış tüm constructorları array e atar
        Constructor[] declaredConstructors = worker.getDeclaredConstructors();
        // iki string parametresi alan constructorın bilgilerini listeye alıyoruz
        Constructor<?> cons = worker.getDeclaredConstructor(String.class,String.class);
        Constructor<?> consEngineer = engineer.getDeclaredConstructor(boolean.class, String[].class);

        // iki tane string parametresi olan constructor ın modifier sayısını döner
        //System.out.println(cons.getModifiers());
        System.out.println(Modifier.toString(cons.getModifiers())); // constructor erişim tipi

        // iki string ve bir integer parametresi olan constructorın modifier sayısnı döner
        Constructor<?> cons2 = worker.getDeclaredConstructor(String.class,String.class,Integer.TYPE);
        // public se 1 private 2 protected 4 değeri ile döner.
       // System.out.println(cons2.getModifiers());
        System.out.println("Modifier: "+ Modifier.toString(cons2.getModifiers()));// constructor erişim tipi
        System.out.println("Part 1 \n");
        // public fields
        Field[] fields = worker.getFields();
        //tüm fields
        Field[] declareadFields = worker.getDeclaredFields();
        //public ve miras aldığı sınıfın methodları (override ettiği methodlar)
        Method[] methods = worker.getMethods();
        Method[] declaredMethods = worker.getDeclaredMethods();
        //public constructorları döner
        for (Constructor c : constructors) {
            System.out.println(("constructor : " + c.getName()));
        }
        System.out.println();
        // tanıtılmış tüm constructorları döner
        for (Constructor c : declaredConstructors) {
            System.out.println(("constructor : " + c.getName()));
        }
        System.out.println();
        //public fieldları döner
        for (Field f : fields) {
            System.out.println(("fields : " + f.getName()));
        }
        System.out.println();
        //tanıtılmış tüm fieldları döner
        for (Field f : declareadFields) {
            System.out.println(("declared fields : " + f.getName()));
        }
        System.out.println();
        // classın public methodları ve classın miras aldığı methodları döner
        for (Method m : methods) {
            System.out.println(("methods : " + m.getName()));
        }
        // class a ait methodları döner (override etmiyorsa miras aldığı methodları dönmez)
        System.out.println();
        for (Method m : declaredMethods) {
            System.out.println(("methods : " + m.getName()));
        }
        // classın bir objesini oluşturduk
        //Object o = worker.newInstance();
        Object o = worker.getDeclaredConstructor(String.class,String.class,Integer.TYPE).newInstance("emre","emre",2500);
        //çalıştırmak istediğimiz methodun adı ve parametrelerini fonksiyona yazıyoruz.
        Method yeniMethod = worker.getMethod("setMaas",    Integer.TYPE);
        // set metoduyla istediğimiz işlemi yaptıktan sonra benzer durumu get methodu içinde yapıyoruz
        Method maasGet = worker.getMethod("getMaas");
        //2500 değerini constructor ile atadığım için aşağıda çağırınca 2500 değeri gelecek
        Object maas = maasGet.invoke(o);
        System.out.println(maas);
        // set ile 2500 olan değeri 1500 yapıyorum.
        yeniMethod.invoke(o,1500);
        maas = maasGet.invoke(o);
        System.out.println(maas);
        // tanımladığımız constructor ın adı
        System.out.println(("name " + cons.getName()));
        System.out.println(("Is accessible? : " + cons.isAccessible()));
        // kurucu içinden başka bir kurucu çağırılıyor mu kontrolü
        System.out.println("IsSynthetic : " + cons.isSynthetic());
        System.out.println("IsSynthetic : " + consEngineer.isSynthetic());
        // Var args geçiyor mu
        System.out.println(("IsVarArgs : " + cons.isVarArgs()));
        System.out.println(("IsVarArgs : " + consEngineer.isVarArgs()));
        //private methodlara erişme
        Method privateFunctionCall = worker.getDeclaredMethod("deneme");
        privateFunctionCall.setAccessible(true);
        privateFunctionCall.invoke(o);


    }
}