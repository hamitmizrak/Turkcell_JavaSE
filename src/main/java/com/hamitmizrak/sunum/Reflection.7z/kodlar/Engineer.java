/**
 * @author Emre YILDIZ
 */
public class Engineer extends Worker
{
    boolean hasPc ;
    Engineer engineer = new Engineer(true,"a","a","a","a");
    public Engineer(boolean hasPc) {
        this.hasPc = hasPc;
    }

    public Engineer(boolean hasPc, String... strings) {
        super(strings);
        this.hasPc = hasPc;
    }

    public Engineer(String isim, String soyisim, boolean hasPc) {
        super(isim, soyisim);
        this.hasPc = hasPc;
    }

    public Engineer(String isim, String soyisim, int maas, boolean hasPc) {
        super(isim, soyisim, maas);
        this.hasPc = hasPc;
    }
}
