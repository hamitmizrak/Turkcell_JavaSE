package example.ocp.q1;

import java.util.ArrayList;
import java.util.Collection;

interface IPerson {
}

class Boss implements IPerson {
    public void doBossStuff() {
        System.out.println("boss");
    }
}

class Employee implements IPerson {
    public void doEmployeeStuff() {
        System.out.println("employee");
    }
}

class Context {
    private ArrayList<IPerson> list = new ArrayList<IPerson>();

    public Collection<IPerson> getPersons() {
        list.add(new Boss());
        list.add(new Employee());
        return list;
    }
}

public class Main {

    public static void main(String[] args) {
        Context context = new Context();


        Collection<IPerson> persons = context.getPersons();
        IPerson iPerson = new Boss();

        for (IPerson person : persons) {

            // now we have to check the type... :-P
            if (person instanceof Boss) {
                ((Boss) person).doBossStuff();
                System.out.println("1");
            }
            else if (person instanceof Employee) {
                ((Employee) person).doEmployeeStuff();
                System.out.println("2");
            }
        }

    }
}
