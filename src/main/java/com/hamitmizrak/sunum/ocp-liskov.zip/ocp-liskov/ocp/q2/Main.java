package example.ocp.q2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

interface IPerson {
    // pulled up method from Boss
    void doStuff();
}
class Boss implements IPerson {
    public void doBossStuff() {
        System.out.println("boss");
    }

    @Override
    public void doStuff() {
        this.doBossStuff();
    }
}
class Employee implements IPerson {
    public void doEmployeeStuff() {
        System.out.println("employee");
    }

    @Override
    public void doStuff() {
        this.doEmployeeStuff();
    }
}

class Context {
    private ArrayList<IPerson> list = new ArrayList<IPerson>();
    public List<IPerson> getPersons() {
        list.add(new Boss());
        list.add(new Employee());
        return list;
    }
}
public class Main {
    public static void main(String[] args) {
        Context context = new Context();

        List<IPerson> persons = context.getPersons();

        for (IPerson person : persons) {
            person.doStuff();
        }
    }
}
